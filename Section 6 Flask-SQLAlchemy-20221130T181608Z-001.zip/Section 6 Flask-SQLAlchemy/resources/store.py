from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from db import db
from models import StoreModel

...


@blp.arguments(StoreSchema)
@blp.response(201, StoreSchema)
def post(self, store_data):
    store = StoreModel(**store_data)
    try:
        db.session.add(store)
        db.session.commit()
    except IntegrityError:
        abort(
            400,
            message="A store with that name already exists.",
        )
    except SQLAlchemyError:
        abort(500, message="An error occurred creating the store.")

    return store
